import requests

def teste():
    print("Teste")